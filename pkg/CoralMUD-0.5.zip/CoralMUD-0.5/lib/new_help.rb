$helpfile_cache = {}

class Helpfile
  def initialize 

  end

end
