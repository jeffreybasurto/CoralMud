# filters for transforming an argument to something else.
class Filter
  include Singleton
  def filt_none old
    return old
  end

  def filt_to_sect old
    Sector.lookup(old) # returns nil on a fail
  end
end

class DisplayFilter
  include Singleton
  def filt_none old
    return old
  end

  # Display it as a sector.
  def filt_to_sect variable_name, sect
    ("%12s" % variable_name) + (":#{sect}")
  end
end

EditorFilters = Filter.instance

### Attached to any class that can be edited automatically with the variable "editor_interface"
class Editor
  attr :lookup
  @@editor_list = {}  ### stored across all editors in existance.  Elegant way to have something to check input against.
  
  def initialize name, p
    @lookup = p
    @editor_name = name    ### the editors name, such as redit
    @editor_commands = [EditorCommand.new("commands", nil, :arg_none, :filt_none, proc{|ed, ch| ch.text_to_player("#{ed.commands_list_get}" + ENDL)}, self),
                        EditorCommand.new("done", nil, :arg_none, :filt_none, proc{|ed, ch| ch.editing = nil}, self)]
    @@editor_list[name] = self
  end

  def add_command command_arg
    log :debug, "#{command_arg}"

    @editor_commands = [command_arg] + @editor_commands
  end

  def self.list
    @@editor_list
  end

  def commands_list_get
    @editor_commands.collect { |c|  c.name }
  end

  ### selects all commands that match arg even partially. 
  def find_command arg
    @editor_commands.select {|c| c.name.start_with?(arg)} 
  end
end

# a single command in the editor_commands tables per Editor created.
class EditorCommand 
  attr :name
  def initialize name, function, arg_type, filter, p, editor, hidden = false
    @name = name
    @function = function
    @arg_type = arg_type
    @filter = filter
    @hidden = hidden
    @proc_fun = p
    @editor = editor
  end

  def to_str
    "EditorCommand: #{name}"
  end

  def filter arg
    EditorFilters.send(@filter, arg)
  end

  def call_fun ch, obj, arg
    log :debug, "#{@proc_fun}"


    if @proc_fun != nil
      log :debug, "calling proc"
      @proc_fun.call @editor, ch, obj, arg
    else
      log :debug, "Value set."
      ch.text_to_char "Value set." + ENDL
      obj.send(@function, arg)
    end
  end
end

### filters
class String
  ### take a string and return a filtered string. Should really take no modifications.
  def str_to_str
    self
  end
end

$editor_lookup_procs = {}  # map of editor to procs for looking up values.
                           # this is initialized when you construct the editor.

#meta programming to define our editor functions and accessors.
class Class  
  # defines the access functions our editor requires for a particular variable.
  ### define the editor.
  def define_editor sym, p
    ### adds the editor name to the class.   For example "redit"
    $editor_lookup_procs[sym] = p
    class_variable_set("@@class_editor", Editor.new(sym.to_s, p))
    define_method("class_editor") do 
      self.class.class_variable_get(:@@class_editor)
    end
    ### add command to global command table for wizards.
    $tabWizCmd << Command.new(sym.to_s,  :arg_int!)

    Player.send(:define_method, "cmd_#{sym}") do |tab_entry, arg|
      
        begin
          found = $editor_lookup_procs[sym].call(arg) # call the proc defined to lookup values.  
        rescue
          text_to_player "Failed on lookup."
        end
        if found == nil
          raise
        end
        instance_variable_set(:@editing,found)
        text_to_player "Success!! You're currently editing #{@editing}"
      end
  end

  def define_editor_field(*accessors)
    accessors.each do |each_hash|
      a_symbol = each_hash[:name] # The name of the variable
      arg_type = each_hash[:arg_type] # Type of argument that is expected to be supplied.
      filter = each_hash[:filter] # filter to use
      p = each_hash[:proc] # if this isn't nil we should use it instead of defining a method.

      temp = class_variable_get(:@@class_editor);           
      e = temp
      temp.add_command EditorCommand.new(a_symbol, "edit_#{a_symbol}".to_sym, arg_type, filter, p, e)
 
      #  text_to_player "Failed on value of lookup #{found} for #{arg}." + ENDL
      # given  attr_editorable [:name, :arg_str] 
      # room.edit_name "Name of a Room"
      define_method("edit_#{a_symbol}".to_sym) do |val|
        # We can assume the data is already correct coming in.
        instance_variable_set("@#{a_symbol}", val)  
      end
    end
  end
end


