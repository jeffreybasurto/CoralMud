class Player
  def cmd_test cte, arg
    view "Items in the room:" + ENDL
    in_room.each_stuff do |obj|
      view "(###{obj.id})" + peek(obj) + ENDL
    end

  end
end
