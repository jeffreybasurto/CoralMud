class Item
  include CoralMUD::FileIO # standard saving mechanisms.
  include CoralMUD::VirtualTags # vtags and indexing

  attr_reader :name, :type, :flags

  def to_configure_properties
    ['@name', '@vtag', '@type', '@flags']
  end

  def short_desc
    @name
  end

  def to_s
    mxptag("send 'edit #{Tag.full_tag(self)}'") + "[Item #{@vtag}]" + mxptag("/send")
  end

  def initialize
    @name = DEFAULT_STRING
    @type = :trash      
  end

  # to create an instance this is called every time.
  # note: it's not an instance of the class. It's an instance of the template with a facade.
  # So it's an instance of an instance.
  def instance
    obj = ItemFacade.new(self, true)   
  end

  def data_transform_on_save map
    vtag = map['@vtag']
    if vtag
      map['@vtag'] = vtag.to_s
    end
    return map
  end


  def data_transform_on_load version, map
    log :debug, "Transforming item."
    # transform the tag using the namespace
    vtag = map['@vtag']
    if vtag
      assign_tag vtag, map['@namespace']
      vtag = @vtag
      map['@vtag'] = vtag
    end
    return map
  end
end

class ItemFacade < Facade
  attr_facade :name
  include CoralMUD::HasStuff
  def initialize thing, assign_id=false
    super thing, assign_id
  end 

  # return an array in this format
  # [[count, "tag", []]
  def self.create_savedata data_set
    return_arr = []
    data_set.each do |item|
      return_arr << [1, Tag.full_tag(item), []]
    end
    return_arr
  end
end



