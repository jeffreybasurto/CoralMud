class Player
  ### command to start editing something. 
  def cmd_edit comm_tab_entry, arg

    case arg
    when nil then thing = [in_room]
    when Array then thing = arg
    else
      # valid tag
      thing = Tag.find_any_obj(arg)
      if !thing
        text_to_player("Nothing found to edit." + ENDL)
        return
      end
    end

    @editing=@editing || []
    @editing.unshift thing[0]

    found = thing.shift
    text_to_player "#Gfound> #{found}" +ENDL
    thing.each do |element|
      text_to_player "#G#{element}#n" +ENDL
    end
    execute_command("show")
  end
end
