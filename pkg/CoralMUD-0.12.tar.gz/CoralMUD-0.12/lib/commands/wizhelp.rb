class Player
  def cmd_wizhelp command_table_entry, arg
    col = 0
    buf = sprintf "#uImmortal Commands#u" + ENDL
    $tabWizCmd.each do |c|
      next if c.hidden
      buf << sprintf(" %-14.14s", c.cmd_name)
      col += 1
      buf << ENDL if col % 5 == 0
    end
    buf << ENDL if col % 5 > 0


    col = e

    buf << "#uImplementor Commands#u" + ENDL
    $tabWizCmd.each do |c|
      next if c.hidden
      buf << sprintf(" %-14.14s", c.cmd_name)
      col += 1
      buf < ENDL if col % 5 == 0
    end
    buf << ENDL if col % 5 > 0

    text_to_player buf
  end
end
