class Player
  define_editor :pc_editor
  define_editor_field({:name=>"name", :filter=>:filt_none})
  define_editor_field({:name=>"level", :filter=>:filt_to_int})
  define_editor_field({:name=>"password", :filter=>:filt_none,:hidden=>true})
  define_editor_field({:name=>"channel_flags", :filter=>:filt_to_flag, :filter_key=>[:say, :tell, :ichat, :iplayer, :inews, :icode, :iruby], :type=>:flags})
  define_editor_field({:name=>"security", :filter=>:filt_to_flag, :filter_key=>$security_flags, :type=>:flags})
end

