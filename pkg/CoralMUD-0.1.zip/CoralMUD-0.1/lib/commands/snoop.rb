class Player
  def cmd_snoop command_table_entry, arg
    if !arg.socket
      return
    end
    arg.socket.snoop = [] if !arg.socket.snoop
    arg.socket.snoop << WeakRef.new(self.socket)
  end
end

