# Anything that actually exists and can be placed in Rooms should mix this in.
module Movable
  attr_accessor :in_room
  def to_room  room  ### anything including this should may be placed into a room.
    if room.is_a? Integer
      room = get_room_index(room)
    end
    room.accept_player(self)
  end

  def from_room
    if in_room != nil
      in_room.remove_player(self)
    end
    in_room = nil
  end
end

# Storable items can be placed in inventory.
module Storable
end

module CoralMUD
  # if class should implement descriptive tags.
  module DescriptiveTag
    # each class including this module gets a 
    @@list_by_tag = {}
    def set_tag str
      str = str.arg_tag!

      # destroy old tag
      @@list_by_tag.delete(@tag) if @tag != nil

      # set new tag and update the list for this tag.
      @tag = str
      @@list_by_tag[@tag] = self 
    end
    # Method for looking up     
    def self.lookup_by_tag tag
      @@list_by_tag[tag]
    end
  end

  # If class can be written to file.
  module FileIO
    # Save any class to a file. Path should be given to the directory to save in.
    # example:  "player/Retnur.yml"
    def save_to_file file
      begin
        File.open( file, 'w' ) do |out|
          YAML::dump gen_configure, out
        end
      rescue Exception=>e
        log :error, "Unable to write: #{file}"
        log_exception e
      end
    end
 
    # Load and configure a class from a file.   Path should be given to the directory to load from.
    # example:  "player/Retnur.yml"
    def load_from_file dir
      begin 
        a = YAML::load_file dir
        @when = Time.now.to_i # For finding out later if it needs to be reloaded.
                              # Class may or may not even make use of this.   Adding it at the time for help file support.
      rescue Exception=>e
        log_exception e
        log :error, "unable to load YAML."
        return nil
      end
      begin
        configure(a)
        return self
      rescue Exception=>e
        log_exception e
        log :error, "Unable to configure: #{dir}"
        return nil
      end
    end

    # convert map to instance.
    def configure data
      version = data[:version]

      log :debug, "Reading configuration data for #{self}"
      # Note: These hooks do *not* need to be defined. 
      # They're only defined if you're using version controlling
      # or if you want more control on how data is transformed beyond generics.
      # hook for calling version_control
      if self.respond_to?:version_control
        data = self.version_control(version, data)
      end

      # Hook for calling data_transform
      if self.respond_to?:data_transform_on_load
        data = self.data_transform_on_load(version, data)
      end

      # load hash into object directly.   
      data.each do |key, value|
        self.instance_variable_set(key, value) # sets all instance variables by name of key.
      end
    end

    # generate the hash we save.
    def gen_configure
      if respond_to?(:to_configure_properties) 
        log :debug, "Generating configuration data for #{self}"
        #If this method is defined it will return an array of variables we must add to this hash.
        config_list = to_configure_properties

        data = {}
        # for each item we must configure...
        config_list.each do |item|
          val = instance_variable_get(item) # grab the value for this key
          data[item] = val # sets the value in our hash
        end

        # hook for transforming the data if need be.
        if respond_to?(:data_transform_on_save)
          data = data_transform_on_save(data)
        end
        return data
      end
    end
  end
end

