class Social
  attr_accessor :meh
  include CoralMUD::FileIO # standard saving mechanisms.
  include CoralMUD::VirtualTags # virtual tag system included.


end
