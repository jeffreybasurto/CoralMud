class Player
  def initialize_security
    @security = {}
  end
end
