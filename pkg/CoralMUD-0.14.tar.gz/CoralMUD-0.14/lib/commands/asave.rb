class Player
  def cmd_asave c_t_e, arg
    text_to_player "All areas saved." + ENDL
    Zone.save_all

  end
end
