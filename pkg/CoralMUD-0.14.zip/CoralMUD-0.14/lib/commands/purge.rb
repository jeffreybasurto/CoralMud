
class Player
  def cmd_purge cme, arg
    # each thing in the room.
    found = []
    found_name = []
    in_room.each_stuff do |obj|
      found << obj
      found_name << peek(obj, false)
    end

    found.each do |obj|
      in_room.remove obj
    end


    view "You destroyed #{"item".en.quantify(found_name.count)}." + ENDL

    if found_name.empty?
    elsif found_name.count == 1
      found_name[0] = "lonely " + found_name[0]
      view "It was " + found_name.en.conjunction + " indeed." + ENDL
    else
      view "Among them "+ found_name.en.conjunction + "." + ENDL
    end


  end
end
