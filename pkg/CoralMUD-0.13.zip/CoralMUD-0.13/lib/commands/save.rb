class Player
  def cmd_save command_table_entry, arg
    text_to_player "Player files are autosaved.  There is no need to save manually." + ENDL
    save_pfile
  end
end
