class NPC
  define_creatable
  define_editor :npc_editor
  define_editor_field({:name=>"vtag", :filter=>:filt_to_tag, :type=>:vtag})
  define_editor_field({:name=>"zone", :filter=>:filt_to_area, :type=>:namespace})
  define_editor_field({:name=>"name", :filter=>:filt_none})

  def self.create ch
    npc = self.new
    npc.namespace = ch.in_room.namespace  # have to set it so gen_generic_tag will work correctly.
    npc.assign_tag Tag.gen_generic_tag(npc), ch.in_room.namespace
    return npc
  end
end
