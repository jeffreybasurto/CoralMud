class Player
  def cmd_goto command_table_entry, arg
    found = Tag.find_any_obj arg

    if found == nil
      p = arg.get_player
      if !p
        text_to_player "That isn't a valid rvnum or character name." + ENDL
        return
      end
      room = p.in_room
    else
      found = found.select {|r| r.is_a?(Room)}
  
      if found == nil || found.empty?
        view "That isn't a valid room or character." + ENDL
        return
      end
    
      room = found[0] # must be of type Room
    end

    if room == in_room
      text_to_player "You are already there." + ENDL
      return
    end

    if (in_room != nil)
      in_room.text_to_room "#{name} disappears in a cloud of sulfur." + ENDL
      in_room.remove_player(self)
    end
    room.accept_player(self)
    room.text_to_room "#{name} appears in a cloud of sulfur." + ENDL
  end
end
