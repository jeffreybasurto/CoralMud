class Player
  def cmd_test cte, arg
    @security = {:edit=>true}
  end
end
