class Player
  def cmd_commands command_table_entry, arg
    f = format_generator

    buf = sprintf "#uCommands#u" + ENDL 
    $tabCmd.sort {|a, b| a.cmd_name <=> b.cmd_name}.each do |c|
      buf << sprintf(" %-14.14s", c.cmd_name)
      buf << f.resume
    end
    buf << ENDL
    text_to_player buf
  end
end

