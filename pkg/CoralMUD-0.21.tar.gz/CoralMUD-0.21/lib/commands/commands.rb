class Player
  def cmd_commands command_table_entry, arg
    f = format_generator

    buf = "#uCommands#u" + ENDL 
    $tabCmd.sort {|a, b| a.cmd_name <=> b.cmd_name}.each do |c|
      buf << " %-14.14s" % c.cmd_name
      buf << f.resume
    end
    buf << ENDL
    view buf
  end
end

