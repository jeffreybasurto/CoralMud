class Player
  def cmd_test cte, arg
    each_stuff do |o|
      view "#{IDN.lookup(o.id)}" + ENDL
    end
  end
end
