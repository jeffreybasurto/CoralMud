
class Player
  def cmd_vlist c,  arg
    if arg == nil
      found = [nil]
    elsif !(found = Tag.find_any_obj(arg))
      view "Namespace not found." + ENDL
      return
    end

    Tag.search_namespace(found[0]) do |something|
      view something.to_s + ENDL
    end
  end
end
