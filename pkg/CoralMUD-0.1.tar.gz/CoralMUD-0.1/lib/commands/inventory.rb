class Player
  def cmd_inventory cte, arg
    view "You are carrying #{"item".en.quantify(count_stuff)}." + ENDL

    found = []
    each_stuff do |thing|
      found << peek(thing, false)
    end

    if found.empty?

    elsif count_stuff == 1
      found[0] = "lonely " + found[0]
      view "It is " + found.en.conjunction + " indeed." + ENDL      
    else
      view "Among them are "+ found.en.conjunction + "." + ENDL
    end
  end
end
