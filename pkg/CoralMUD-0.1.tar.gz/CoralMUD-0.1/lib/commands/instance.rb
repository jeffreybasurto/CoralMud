class Player

  def cmd_instance cte, arg
    found = Tag.find_any_obj arg
    if !found
      text_to_player "No object found to instance from." + ENDL
      return
    end

    if !found[0].respond_to?(:instance)
      text_to_player "Error:  No method to instance from #{found[0].class}." + ENDL
      return
    end

    obj = found[0].instance
    text_to_player "#{peek(obj)} generated." + ENDL

    if obj.is_a? Item
      self.accept(obj)
    elsif obj.is_a? NPC
      self.in_room.accept_player(obj)
    end

  end
end
