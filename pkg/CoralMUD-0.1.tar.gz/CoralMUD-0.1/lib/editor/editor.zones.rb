class Zone
  define_creatable
  define_editor :zone_edit
  define_editor_field({:name=>"vtag", :filter=>:filt_to_tag, :type=>:vtag})
  define_editor_field({:name=>"name", :filter=>:filt_none})

end
