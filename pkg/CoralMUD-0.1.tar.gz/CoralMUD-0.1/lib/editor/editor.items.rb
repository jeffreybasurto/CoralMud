class Item
  define_creatable
  define_editor :item_editor
  define_editor_field({:name=>"vtag", :filter=>:filt_to_tag, :type=>:vtag})
  define_editor_field({:name=>"zone", :filter=>:filt_to_area, :type=>:namespace})
  define_editor_field({:name=>"name", :filter=>:filt_none})

  def self.create ch
    item = self.new
    item.namespace = ch.in_room.namespace  # have to set it so gen_generic_tag will work correctly.
    item.assign_tag Tag.gen_generic_tag(item), ch.in_room.namespace
    return item
  end
end

