class Player
  def cmd_quit command_table_entry, arg
    # log the attempt
    log :info, sprintf("%s has left the game.", @name)
    save_pfile
    @socket.player = nil
    free_player
    @socket.close_connection
  end
end
