class Player
  def cmd_tell table_entry, target, message
    if target.include?"@"
      to = target.split('@')

      if !to[0] || !to[1]
        text_to_player "That doesn't seem to be a valid target." + ENDL
        return
      end

      $imclock.synchronize do 
        $imcclient.private_send(@name.capitalize, to[0], to[1], message)
        text_to_player "#RYou tell #{target}, '#{message}'#n" + ENDL
      end
      return
    end
    text_to_player "Not quite implemented yet." + ENDL
  end
end
