class Player
  def cmd_linkdead command_table_entry, arg
    found = false
    $dplayer_list.each do |xPlayer|
      if xPlayer.socket.nil?
        text_to_player "%s is linkdead." % xPlayer.name + ENDL
        found = true
      end
    end
    if !found
      text_to_player "Noone is currently linkdead." + ENDL
    end
  end
end
