
# Generates separators for output to players.
# example is in cmd_commands
def format_generator length=4
  Fiber.new do
    count = 0
    loop do
      count += 1
      if count == length
        count = 0
        Fiber.yield ENDL
      else
        Fiber.yield ""
      end
    end
  end
end


#is instanced off for player command tables.
class CommandTable
  attr_accessor :cmds
  def initialize
    @cmds = []
    init_cmd_table
  end

  # This is the initialize function that must be called manually to grab refernces from the global table.
  def init_cmd_table
    # Right now just adding all commands into the copied table. Maybe later a check for if is immortal or not.
    $tabCmd.each do |c|
      @cmds << c
    end
    $tabWizCmd.each do |c|
      @cmds << c
    end
    return true
  end


  def cmd_lookup com

    @cmds.each do |c|
      if c.must_type_full == true
        return c if com == c.cmd_name
      else
        return c if is_prefix com, c.cmd_name
      end
    end

    ### fail, if we found partial match we should do something about it here later.

    return nil
  end
end

#
# The command table, very simple, but easy to extend.
# This table is the prototype for the global table every 
# character loads with. The reference the elements, not copy.
#
$tabCmd += [
  Command.new("north",    :arg_none),
  Command.new("east",     :arg_none),
  Command.new("south",    :arg_none),
  Command.new("west",     :arg_none),
  Command.new("quit",     :arg_none,  true),
  Command.new("who",      :arg_none),
  Command.new("look",     [[:arg_int!], [:arg_none]]),
  Command.new("commands", :arg_none),
  Command.new("help",     :arg_word!),
  Command.new("say",      :arg_str),
  Command.new("save",     :arg_none),
  Command.new("track",    :arg_player_in_game!),

  Command.new("inews",    :arg_str),
  Command.new("iruby",     :arg_str),
  Command.new("ichat",     :arg_str),
  Command.new("icode",     :arg_str),
  Command.new("igame",     :arg_str),
  Command.new("ichannels", :arg_str),
  Command.new("test",     :arg_none),
#imm commands moved to new table.  Most players will not need to access other table.
]

$tabCmd.uniq!

$tabWizCmd += [
  Command.new("dig",   :arg_str),
  Command.new("goto",  :arg_int!),
  Command.new("wizhelp",  :arg_none),
  Command.new("linkdead", :arg_none),
  Command.new("shutdown", :arg_none, true),
  Command.new("buildwalk",  :arg_none),
]

$tabWizCmd.uniq!

class String
  ### check to see if expected args exist for this string.
  ### expected must be a single dimension array.
  def check_args expected
    s = self.dup
    product = []
    expected.each do |arg_expected|
      if arg_expected == :arg_none and s != ''
        return false
      end
      processed = s.send(arg_expected)
      if processed == nil and arg_expected != :arg_none
        return false ### fail  
      end
      product << processed
    end
    return product
  end
end
class Player
  ### Function to execute a command just as though it were typed.
  ### example:   player.execute("look")
  ###            player.execute("look", "at Retnur");
  def execute_command comm, arg=""
    if (c = self.command_table.cmd_lookup(comm))
      args_to_pass = [c] #First arg is always command table lookup, and once args populate the array we'll splat it.
      failure = true
      ### If it's an array passed it has multiple arguments possibly.
      ### If not it represents a single argument.   These are defined on the table.
      if c.cmd_args.is_a?(Array) == false
        c.cmd_args = [[c.cmd_args]]
      end

      c.cmd_args.each do |each_arr|
      ### okay, since there is arrays involved it will use the full format
      ###  Like [[arg_str], [arg_none]]
      ### for each array contained we must check to see if it's valid from start to end.
      ### If not valid we go to the next.  All arrays must fail for it really to fail the checks.
        processed = arg.check_args each_arr
        if processed == false          
          next
        end
        failure = false ### found a buyer.
        args_to_pass = args_to_pass + processed  ### This is how we're passing it. win
        break
      end
 
      ### if we failed let's report our failure.
      if failure == true
        if c.respond_to? :arg_failure_msg
          # Failure message defined.  Pass to this method which arg failed.
          text_to_player c.arg_failure_msg
        else
          text_to_player "Bad arguments (#{arg}) for #{c.cmd_name} command." + ENDL
        end
        return 
      end
      ### dispatched to cmd_function
      begin
        self.send(c.cmd_funct, *args_to_pass)
      rescue Exception=>e
        log_exception e
        text_to_player "Command failed." + ENDL
      end
    else
      self.text_to_player "No such command." + ENDL
    end
  end

  ### command to start editing something. 
  def cmd_edit command_table_entry, arg1, arg2
    if arg1 == :error_not_valid
      text_to_player 
    end

    puts "#{arg1} #{arg2}#{ENDL}"
  end

  ### If no argument display all available channels.
  def cmd_ichannels command_table_entry, arg
    buf = "The following commands are available:" + ENDL
    i = 0
    $imc_channel_list.each_pair do |k,v|
      i += 1
      z = "[On]"     
      buf << v[1] + ("[" + i.to_s + "] " + v[0]).ljust(25) + k.to_s.ljust(12) + z + ENDL 
    end
    text_to_player buf
  end

  def cmd_iruby command_table_entry, arg
    $imclock.synchronize do
      $imcclient.channel_send("#{name.capitalize}", "Server02:iRuby", arg)
    end
  end

  def cmd_iadmin command_table_entry, arg
    $imclock.synchronize do
      $imcclient.channel_send("#{name.capitalize}", "Server01:admin", arg, "ice-msg-p")
    end
  end

  def cmd_igame command_table_entry, arg
    if arg == nil || arg.length == 0
      ### Toggle icode channel
      if (found = @channel_flags[:icode]) == nil
        text_to_player "You will no longer observe the igame channel." + ENDL
        ### Currently channel is on. Turn it off with user restriction.
        @channel_flags[:igame] = :channel_user_off
      else
        if found == :channel_mute_off
          text_to_player "You are not allowed to observe the igame channel." + ENDL
        else
          ### Currently the channel is off. Remove all restrictions.
          text_to_player "You can now observe the igame channel." + ENDL
          @channel_flags.delete(:igame)
        end
      end
    else
      $imclock.synchronize do
        $imcclient.channel_send("#{name.capitalize}", "Server02:igame", arg)
      end
    end
  end


  def cmd_icode command_table_entry, arg
    if arg == nil || arg.length == 0
      ### Toggle icode channel
      if (found = @channel_flags[:icode]) == nil
        text_to_player "You will no longer observe the icode channel." + ENDL
        ### Currently channel is on. Turn it off with user restriction.
        @channel_flags[:icode] = :channel_user_off
      else
        if found == :channel_mute_off
          text_to_player "You are not allowed to observe the icode channel." + ENDL
        else
          ### Currently the channel is off. Remove all restrictions.
          text_to_player "You can now observe the icode channel." + ENDL
          @channel_flags.delete(:icode)
        end
      end      
    else
      $imclock.synchronize do
        $imcclient.channel_send("#{name.capitalize}", "Server02:icode", arg)
      end
    end
  end
  
  def cmd_ichat command_table_entry, arg
    if arg == nil || arg.length == 0
      ### Toggle icode channel
      if (found = @channel_flags[:ichat]) == nil
        text_to_player "You will no longer observe the ichat channel." + ENDL
        ### Currently channel is on. Turn it off with user restriction.
        @channel_flags[:ichat] = :channel_user_off
      else
        if found == :channel_mute_off
          text_to_player "You are not allowed to observe the ichat channel." + ENDL
        else
          ### Currently the channel is off. Remove all restrictions.
          text_to_player "You can now observe the ichat channel." + ENDL
          @channel_flags.delete(:ichat)
        end
      end
    else
      $imclock.synchronize do
        $imcclient.channel_send("#{name.capitalize}", "Server01:ichat", arg)
      end
    end
  end
  def cmd_inews command_table_entry, arg
    if arg == nil || arg.length == 0
      ### Toggle icode channel
      if (found = @channel_flags[:inews]) == nil
        text_to_player "You will no longer observe the inews channel." + ENDL
        ### Currently channel is on. Turn it off with user restriction.
        @channel_flags[:inews] = :channel_user_off
      else
        if found == :channel_mute_off
          text_to_player "You are not allowed to observe the inews channel." + ENDL
        else
          ### Currently the channel is off. Remove all restrictions.
          text_to_player "You can now observe the inews channel." + ENDL
          @channel_flags.delete(:inews)
        end
      end
    else
      $imclock.synchronize do
        $imcclient.channel_send("#{name.capitalize}", "Server02:inews", arg)
      end
    end
  end

  def cmd_sprint command_table_entry, arg
    if flags.include?("sprint")
      flags.delete("sprint")
      text_to_player "Sprint off." + ENDL
    else
      flags << "sprint"
      text_to_player "Sprint enabled." + ENDL
    end 
  end
  def cmd_stop arg
    stop
  end

  def cmd_buildwalk command_table_entry, arg
    # either set build walk or remove it.
    if flags.include?("build walk")
      flags.delete("build walk")
      text_to_player "Build walk disabled." + ENDL
    else
      flags << "build walk"
      text_to_player "Build walk enabled." + ENDL
    end
  end

  def cmd_dig command_table_entry, arg
    dir = ""
    one_arg! arg, dir
    
    room = in_room
    i = dir.exit_code_to_i
    return if i == nil

    if !((0..3) === i)
      text_to_player "Invalid exit." + ENDL
      return false
    end
    r = AreaMap.find_room(in_room, [AreaMap.offsetx(0,i), AreaMap.offsety(0,i)])

    if r == nil
        CityRoom.dig_rooms(in_room.vnum, Area.gen_vnum(in_room.vnum/1000), i)
    else
        CityRoom.dig_rooms(in_room.vnum, r.vnum, i)
    end
    return true
  end
  def goto_make_room vnum
    if vnum <= 0
      text_to_player "Invalid room. Cannot create." + ENDL
      return
    end

    r = CityRoom.new(vnum)
    text_to_player "Created." + ENDL
    return r
  end

  # target a specific 
  def cmd_target command_table_entry, arg
   
    
  end
  def cmd_goto command_table_entry, arg
    vnum = Integer(arg) rescue nil

    if (vnum == nil)
      p = arg.get_player
      if p != nil
        # we got our room.
      else
        text_to_player "That isn't a valid rvnum or character name." + ENDL
        return
      end
    end

    if vnum == nil
      room = p.in_room
    else
      room = get_room_index vnum
    end 

    # if the room does not exist let's create it.
    if room == nil
      text_to_player "That room does not seem to exist." + ENDL
      room = goto_make_room vnum
    end

    if room == in_room
      text_to_player "You are already there." + ENDL
      return
    end

    if (in_room != nil)
      in_room.text_to_room "%s disappears in a cloud of sulfur." % name + ENDL
      in_room.remove_player(self)
    end
    room.accept_player(self)
    room.text_to_room "%s appears in a cloud of sulfur." % name + ENDL
  end

  def cmd_track command_table_entry, r
    self.pathtarget = r.in_room
    in_room.map_to_player(self, 36, 18)
    self.pathtarget = nil
  end

  def cmd_debug command_table_entry, arg
    damage(1)
    text_to_player "#{health} #{damage}" + ENDL
    heal(1)
    text_to_player "#{health} #{damage}" + ENDL
  end 

  def buildwalk(dir)
      i = dir
      r = AreaMap.find_room(in_room, [AreaMap.offsetx(0,i), AreaMap.offsety(0,i)])

      if r == nil
        CityRoom.dig_rooms(in_room.vnum, Area.gen_vnum(in_room.vnum/1000), i)
      else
        CityRoom.dig_rooms(in_room.vnum, r.vnum, i)
      end
  end
  def cmd_east command_table_entry, arg
    text_to_player "You walk east." + ENDL
    if !in_room.exit_list[1] 
      if flags.include?("build walk")
        buildwalk(1)
      else
        text_to_player "You can't go that direction." + ENDL
        return
      end
    end
    in_room.exit_list[1].enter(self)
  end

  def cmd_south command_table_entry, arg
    text_to_player "You walk south." + ENDL

    if !in_room.exit_list[2]
      if flags.include?("build walk")
        buildwalk(2)
      else
        text_to_player "You can't go that direction." + ENDL
        return
      end
    end
    in_room.exit_list[2].enter(self)
  end
  def cmd_west command_table_entry, arg
    text_to_player "You walk west." + ENDL
    if !in_room.exit_list[3]
      if flags.include?("build walk")
        buildwalk(3)
      else
        text_to_player "You can't go that direction." + ENDL
        return
      end
    end 
    in_room.exit_list[3].enter(self)
  end
  def cmd_north command_table_entry, arg
    text_to_player "You walk north." + ENDL
    if !in_room.exit_list[0]
      if flags.include?("build walk")
        buildwalk(0)
      else
        text_to_player "You can't go that direction." + ENDL
        return
      end
    end
    in_room.exit_list[0].enter(self)
  end

  # Look command function
  def cmd_look command_table_entry, arg
    if arg.is_a?(Integer)
      p = in_room.map_to_player(self, 36+arg, 14+arg/3)
    else
      p = in_room.map_to_player(self)
    end

    text_to_player "You see..." + ENDL
    in_room.people.each do |actor|
      next if actor == self
      text_to_player "#{actor.name} is here." + ENDL
    end
  end


  def cmd_shutdow command_table_entry, arg
    text_to_player ("If you want to shutdown you must type it out." + ENDL)
  end 

  def cmd_shutdown command_table_entry, arg
    text_to_world ("The game is rebooting.  Please come back in a few minutes." + ENDL)
    $shut_down = true
  end

  def cmd_linkdead command_table_entry, arg
    found = false
    $dplayer_list.each do |xPlayer|
      if xPlayer.socket.nil?
        text_to_player "%s is linkdead." % xPlayer.name + ENDL
        found = true
      end
    end
    if !found
      text_to_player "Noone is currently linkdead." + ENDL
    end
  end

  def cmd_help command_table_entry, arg
    if arg == ''
      length = 65
      col = 0
      buf = "__HELP_FILES__".ljust(length, '_') + ENDL
      $help_list.each do |pHelp|
        buf << " %-19.18s" % pHelp.keyword
        col += 1
        buf << ENDL if col % 4 == 0
      end
      buf << ENDL if col % 4 != 0
      buf << "Syntax:  help <topic>" + ENDL
      text_to_player buf
      return;
    end
    if !check_help self, arg
      text_to_player "Sorry, no such helpfile." + ENDL
    end
  end

  def cmd_who command_table_entry, arg
    width = 60
    buf =  "_".center(width, '_') + ENDL
    buf << "#u"+ "__players_online__".ljust(width, '_') + "#u" + ENDL
    $dsock_list.each do |dsock|
      next if dsock.state != :state_playing
      xPlayer = dsock.player
      next if xPlayer == nil
      buf << "#u=#u" + sprintf(" %-12s   %s", xPlayer.name, dsock.addr).ljust(60-2) + "#u=#u" + ENDL
    end
    buf << "#u" + "".center(width, '=') + "#u" + ENDL
    text_to_player buf
  end

  def cmd_wizhelp command_table_entry, arg
    col = 0
    buf = sprintf "#uImmortal Commands#u" + ENDL
    $tabWizCmd.each do |c|
      next if c.hidden
      buf << sprintf(" %-14.14s", c.cmd_name)
      col += 1
      buf << ENDL if col % 5 == 0
    end
    buf << ENDL if col % 5 > 0


    buf << "#uImplementor Commands#u" + ENDL
    $tabWizCmd.each do |c|
      next if c.hidden
      buf << sprintf(" %-14.14s", c.cmd_name)
      col += 1
      buf < ENDL if col % 5 == 0
    end
    buf << ENDL if col % 5 > 0

    text_to_player buf
  end


  def cmd_commands command_table_entry, arg
    f = format_generator

    buf = sprintf "#uCommands#u" + ENDL 
    $tabCmd.sort {|a, b| a.cmd_name <=> b.cmd_name}.each do |c|
      buf << sprintf(" %-14.14s", c.cmd_name)
      buf << f.resume
    end
    buf << ENDL
    text_to_player buf
  end

  def cmd_save command_table_entry, arg
    text_to_player "Player files are autosaved, there is no need to save manually." + ENDL
    save_pfile
  end

  def cmd_say command_table_entry, arg
    if arg == ''
      text_to_player "Say what?" + ENDL
      return
    end
    communicate self, arg, :comm_local
  end

  def cmd_qui command_table_entry, arg
    text_to_player "If you want to quit you must type it out." + ENDL
  end 

  def cmd_quit command_table_entry, arg
    # log the attempt
    log :info, sprintf("%s has left the game.", @name)
    save_pfile
    @socket.player = nil
    free_player
    @socket.close_connection
  end

  def cmd_test cte, arg
    d = gen_configure

    log :debug, "#{d}"

    configure(d) # configure this object based on d
  end

end

module YAML

end

def yamltest

  File.open("yamltest.yml", "w") do |file|
    ### Dumps room attributes.
    YAML::dump :field_tag, file
    ### Dump Exits in an array format.
    YAML::dump "", file

    @exit_list.each do |e|
      if e != nil
        YAML::dump [e.direction, e.towards_room.vnum], f
      end
    end
  end
end


