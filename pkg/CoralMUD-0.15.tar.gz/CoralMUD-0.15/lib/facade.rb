class Object
  def metaclass
    class << self; self; end
  end
end

class IDN
  include Singleton
  def self.newid
    if !@idnum
      File.open('data/idnum.txt', 'r') do |fin|  
        @idnum = YAML::load(fin)
      end  
    end
    @idnum += 1
    File.open('data/idnum.txt', 'w' ) do |out|
      YAML::dump @idnum, out
    end
    @idnum
  end
end

# used to build facades of another class.   Particularly useful for saving memory on instances of template objects...like items or mobiles.
class Class
  def attr_facade (*attributes)
    attributes.each do |att|
      # for each var
      define_method("#{att}=") do |val|
        return if !val
        self.metaclass.send(:define_method, "#{att}") do 
          instance_variable_get("@#{att}")
        end
        instance_variable_set("@#{att}",val)
      end
    end
  end
end

class Facade
  def initialize thing, assign_id=true
    @id = IDN.newid if assign_id
    @hides = thing # thing hides behind facade
  end

  def id
    @id
  end

  def method_missing name, *args
    @hides.send(name, *args)
  end

  def to_s
    "#{@hides}"
  end

  def is_a? type
    return @hides.is_a? type
  end

  def ===(other)
    return @hides.is_a? other
  end

end

class ATest
  attr_accessor :name
  def initialize
    @name = "test"
  end
end

class TestFacade < Facade
  attr_facade :name
  def initialize hides, flag
    super hides, flag
  end
end

test = ATest.new
facade = TestFacade.new(test, false)

def puts_test test, facade
  puts "test.name:   " + test.name
  puts "facade.name: " + facade.name
end

puts_test(test, facade)
facade.name = facade.name + "ownted"
puts_test(test, facade)
facade2 = TestFacade.new(test,false)
puts_test(test, facade2)
