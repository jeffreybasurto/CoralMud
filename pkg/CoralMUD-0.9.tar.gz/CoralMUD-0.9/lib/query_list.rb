class Functor
  attr_reader :val, :fun
  # defaults are set up for Items
  def initialize type, val, options={}
    @options = {:name=>:name, :id=>:id}.merge(options)
    @val, @val2 = val
    @fun = type
  end
  # call this functor with an array to query. 
  def call data_set
    self.send(@fun, data_set)
  end 

  private
  def match data_set
    data_set.select do |obj| 
      obj.send(@options[:name]).include?(@val)
    end
  end
  def idn data_set
    data_set.select { |obj| obj.send(@options[:id]).to_s.include? @val}
  end 
  def specific data_set
    v = data_set[@val.to_i-1]
    v ? [v] : []
  end
  def times data_set
    data_set[0..@val.to_i-1]
  end
  def all data_set
    data_set
  end
end

# query a list (designed for objects)
# example:   query_list "2.sword", inventory_of_items
def query_list s, list
  s = s.split '.'
  def map_to_function filter
    sym = case filter
      when /^#(\d+)$/ then :idn
      when /^x(\d+)$/ then :times      
      when /^(\d+)$/  then :specific
      when /^(all)$/  then :all
      when /^(.*)$/   then :match
      else 
        raise "bad input"
    end
    return Functor.new(sym, $~.captures)
  end

  funs = []
  s.each do |filter|
    funs.unshift map_to_function(filter)
  end

  unshift_exceptions = [:times, :all, :specific]
  funs.push Functor.new(:specific, 1) if !unshift_exceptions.include? funs[-1].fun

  funs.each do |functor|
    list = functor.call list
  end
  return list
end

